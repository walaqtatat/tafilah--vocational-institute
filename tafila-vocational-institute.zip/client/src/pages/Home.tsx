import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  ArrowUpLeft,
  Baby,
  BarChart3,
  BriefcaseBusiness,
  CalendarDays,
  Check,
  ChevronDown,
  ChevronLeft,
  Clock3,
  Code2,
  Cookie,
  Crosshair,
  Database,
  ExternalLink,
  Facebook,
  GraduationCap,
  HeartHandshake,
  Instagram,
  Laptop,
  Menu,
  MessageCircle,
  Phone,
  Scissors,
  Search,
  ShieldCheck,
  Sparkles,
  Star,
  Target,
  Users,
  X,
  type LucideIcon,
} from "lucide-react";

type Specialty = {
  title: string;
  eyebrow: string;
  description: string;
  image: string;
  icon: LucideIcon;
  duration: string;
  level: string;
  skills: string[];
  opportunities: string[];
};

const imageBase = "/manus-storage/";

const specialties: Specialty[] = [
  {
    title: "حاضنات أطفال",
    eyebrow: "رعاية · إنسان",
    description: "تدريب عملي على رعاية الأطفال والتعامل معهم وتوفير بيئة آمنة وسليمة لنموهم.",
    image: "https://images.unsplash.com/photo-1596464716127-f2a82984de30?auto=format&fit=crop&w=900&q=85",
    icon: Baby,
    duration: "6 أشهر",
    level: "مبتدئ",
    skills: ["سلامة الطفل والإسعافات الأولية", "التواصل مع الأطفال", "الأنشطة التعليمية والترفيهية"],
    opportunities: ["حضانات الأطفال", "مراكز الرعاية", "العمل الحر في رعاية الأطفال"],
  },
  {
    title: "مساعد حلواني",
    eyebrow: "إبداع · مذاق",
    description: "تعلم إعداد الحلويات والمعجنات والمنتجات المختلفة وفق أساليب مهنية وصحية.",
    image: "https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=900&q=85",
    icon: Cookie,
    duration: "6 أشهر",
    level: "مبتدئ",
    skills: ["تقنيات الخَبز والتزيين", "اشتراطات الصحة والسلامة", "حساب الكميات والتكلفة"],
    opportunities: ["المخابز والحلويات", "المطابخ الإنتاجية", "مشروع منزلي"],
  },
  {
    title: "مساعد حلاق نسائي",
    eyebrow: "جمال · ثقة",
    description: "أساسيات العناية بالشعر والجمال والقص والصبغات والتسريحات بمعايير السلامة والنظافة.",
    image: "https://images.unsplash.com/photo-1562322140-8baeececf3df?auto=format&fit=crop&w=900&q=85",
    icon: Scissors,
    duration: "6 أشهر",
    level: "مبتدئ",
    skills: ["قص الشعر والتسريحات", "العناية بفروة الرأس", "التعقيم والتعامل الآمن مع المواد"],
    opportunities: ["صالونات التجميل", "مراكز العناية", "مشروع صالون خاص"],
  },
  {
    title: "مدخل بيانات",
    eyebrow: "رقمنة · دقة",
    description: "تدريب على إدخال البيانات وتنظيمها واستخدام الحاسوب والبرامج المكتبية والمهارات الرقمية.",
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=900&q=85",
    icon: Database,
    duration: "6 أشهر",
    level: "متوسط",
    skills: ["الكتابة السريعة وإدارة الملفات", "Excel وWord", "أمن المعلومات الأساسي"],
    opportunities: ["المكاتب والشركات", "مراكز الخدمات", "العمل عن بُعد"],
  },
  {
    title: "خياط نساء",
    eyebrow: "حرفة · استقلال",
    description: "خياطة وتصميم الملابس النسائية وأخذ القياسات واستخدام آلات الخياطة والتشطيب المهني.",
    image: `${imageBase}hero-sewing_024248c3.jpg`,
    icon: Scissors,
    duration: "6 أشهر",
    level: "مبتدئ",
    skills: ["أخذ القياسات وإعداد الباترون", "تشغيل آلات الخياطة", "التشطيب وضبط الجودة"],
    opportunities: ["مشاغل الخياطة", "مصانع الألبسة", "العمل الحر والتفصيل المنزلي"],
  },
];

const programs = [
  { title: "مشروع أرضي", description: "مساحة عملية لتحويل المهارة إلى فكرة منتجة ومشروع قابل للنمو.", icon: Target },
  { title: "ريادة الأعمال", description: "جلسات وأدوات تساعدك على فهم السوق وبناء نموذج عمل واقعي.", icon: BriefcaseBusiness },
  { title: "المهارات الحياتية", description: "تواصل وقيادة وثقة بالنفس تكمّل مهارتك المهنية.", icon: HeartHandshake },
  { title: "التمكين والتشغيل", description: "دعم وتوجيه لخطوتك التالية نحو فرصة عمل أو مشروعك الخاص.", icon: GraduationCap },
  { title: "الورش المهنية", description: "ورش قصيرة مركّزة تفتح لك أبواباً جديدة للتعلّم والتجربة.", icon: Sparkles },
  { title: "الأنشطة المجتمعية", description: "حضور فاعل في المجتمع ومبادرات تصنع أثراً يتجاوز المعهد.", icon: Users },
];

const news = [
  { date: "18 أيلول 2026", type: "ورشة عمل", title: "من الفكرة إلى المنتج: ورشة تطبيقية في ريادة الأعمال", image: "https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=900&q=85" },
  { date: "02 أيلول 2026", type: "نشاط مجتمعي", title: "مبادرة مهارات تصنع أثراً بمشاركة متدربات المعهد", image: "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=900&q=85" },
  { date: "24 آب 2026", type: "تخريج", title: "نحتفي بدفعة جديدة من الخريجات الجاهزات لسوق العمل", image: `${imageBase}mentorship_d7425e15.jpg` },
];

const gallery = [
  { src: `${imageBase}hero-sewing_024248c3.jpg`, label: "تدريب عملي في مشغل الخياطة" },
  { src: `${imageBase}sewing-detail_949d909c.jpeg`, label: "التطبيق العملي على الآلات" },
  { src: "https://images.unsplash.com/photo-1529390079861-591de354faf5?auto=format&fit=crop&w=1000&q=85", label: "تعلّم تشاركي وداعم" },
  { src: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1000&q=85", label: "مهارات تصنع الثقة" },
  { src: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=1000&q=85", label: "ورش ومشاريع تطبيقية" },
  { src: "https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&w=1000&q=85", label: "مجتمع مهني متعاون" },
];

const faqs = [
  ["كيف يمكنني التسجيل؟", "اضغطي على زر التسجيل الإلكتروني، ثم انتقلي إلى بوابة مؤسسة التدريب المهني وأكملي طلب الالتحاق بالتخصص المناسب."],
  ["ما التخصصات المتاحة؟", "يتوفر حالياً: حاضنات أطفال، مساعد حلواني، مساعد حلاق نسائي، مدخل بيانات، وخياط نساء."],
  ["من يمكنه الالتحاق بالمعهد؟", "يستقبل المعهد الفتيات والسيدات الراغبات في اكتساب مهارة مهنية، وفق شروط القبول المعلنة من مؤسسة التدريب المهني."],
  ["ما مدة التدريب؟", "المدة الموضحة للتخصصات الحالية هي ستة أشهر، وقد تختلف حسب البرنامج أو الدورة المعلنة."],
  ["هل يوجد تدريب عملي؟", "نعم. تعتمد البرامج على التطبيق العملي داخل الورش والمشاغل إلى جانب المعرفة النظرية."],
  ["كيف أتواصل مع المعهد؟", "يمكنك التواصل عبر الهاتف 06-6588481 أو واتساب الدعم الفني 0798137070."],
];

function SectionHeading({ kicker, title, description, light = false }: { kicker: string; title: string; description: string; light?: boolean }) {
  return (
    <div className={`section-heading ${light ? "section-heading-light" : ""}`}>
      <span className="section-kicker">{kicker}</span>
      <h2>{title}</h2>
      <p>{description}</p>
    </div>
  );
}

function LogoMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`brand ${compact ? "brand-compact" : ""}`}>
      <div className="brand-mark"><span>م</span><i /></div>
      <div className="brand-copy"><strong>مؤسسة التدريب المهني</strong><small>معهد الطفيلة إناث</small></div>
    </div>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [selected, setSelected] = useState<Specialty | null>(null);
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 520);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const stats = useMemo(() => [
    ["05", "تخصصات مهنية"],
    ["+240", "متدربة سنوياً"],
    ["+18", "دورة وورشة"],
    ["12", "شراكة مجتمعية"],
  ], []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div dir="rtl" className="site-shell">
      <header className="site-header">
        <div className="topline"><div className="container topline-inner"><span>مؤسسة التدريب المهني · فرع الطفيلة</span><span className="topline-note"><ShieldCheck size={14} /> بيئة تعلم آمنة وملهمة</span></div></div>
        <div className="container nav-wrap">
          <a href="#الرئيسية" onClick={closeMenu} aria-label="العودة للرئيسية"><LogoMark /></a>
          <nav className={menuOpen ? "main-nav open" : "main-nav"} aria-label="التنقل الرئيسي">
            <a href="#عن-المعهد" onClick={closeMenu}>عن المعهد</a>
            <a href="#التخصصات" onClick={closeMenu}>التخصصات</a>
            <a href="#البرامج" onClick={closeMenu}>البرامج</a>
            <a href="#الأنشطة" onClick={closeMenu}>الأنشطة</a>
            <a href="#المعرض" onClick={closeMenu}>المعرض</a>
            <a href="#تواصل" onClick={closeMenu}>تواصل معنا</a>
            <a className="nav-mobile-cta" href="https://ereg.vtc.gov.jo/" target="_blank" rel="noreferrer" onClick={closeMenu}>سجّلي الآن <ArrowLeft size={16} /></a>
          </nav>
          <a className="button button-small button-primary nav-cta" href="https://ereg.vtc.gov.jo/" target="_blank" rel="noreferrer">سجّلي الآن <ArrowLeft size={16} /></a>
          <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="فتح القائمة" aria-expanded={menuOpen}>{menuOpen ? <X /> : <Menu />}</button>
        </div>
      </header>

      <main>
        <section id="الرئيسية" className="hero-section">
          <div className="hero-pattern" />
          <div className="container hero-grid">
            <div className="hero-copy reveal">
              <div className="eyebrow-pill"><Sparkles size={15} /> مهارة · ثقة · مستقبل</div>
              <h1>مهارة اليوم،<br /><em>فرصة الغد.</em></h1>
              <p>نمنحكِ المعرفة والخبرة العملية التي تفتح لكِ أبواب سوق العمل، وتحوّل شغفك إلى مسار مهني واضح.</p>
              <div className="hero-actions"><a href="#التخصصات" className="button button-primary">اكتشفي تخصصاتنا <ArrowLeft size={18} /></a><a href="https://ereg.vtc.gov.jo/" target="_blank" rel="noreferrer" className="button button-ghost">التسجيل الإلكتروني <ExternalLink size={17} /></a></div>
              <div className="hero-trust"><div className="avatar-stack"><span>ن</span><span>ر</span><span>س</span><span>+</span></div><div><strong>خطوتكِ الأولى تبدأ هنا</strong><small>تدريب مهني يواكب فرص الغد</small></div></div>
            </div>
            <div className="hero-visual reveal reveal-delay">
              <div className="hero-image-frame"><img src={`${imageBase}hero-close-sewing_af84ca2d.jpg`} alt="متدربة خلال التدريب العملي على تصميم وخياطة الملابس" /><div className="hero-image-wash" /></div>
              <div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" />
              <div className="floating-card floating-card-top"><span className="floating-icon"><GraduationCap size={20} /></span><div><strong>تعلم تطبيقي</strong><small>خبرة تُصنع باليد</small></div></div>
              <div className="floating-card floating-card-bottom"><span className="floating-icon coral"><Star size={18} fill="currentColor" /></span><div><strong>أكثر من 240</strong><small>متدربة كل عام</small></div></div>
              <div className="hero-stamp"><span>VTC</span><small>تدريب يصنع<br />المستقبل</small></div>
            </div>
          </div>
          <div className="hero-bottom-bar"><div className="container hero-bottom-inner"><span>معاً نحو مستقبل مهني أفضل</span><div className="scroll-cue"><span>اكتشفي المزيد</span><ArrowUpLeft size={17} /></div></div></div>
        </section>

        <section id="عن-المعهد" className="intro-section section-pad">
          <div className="container intro-grid"><div className="intro-aside"><div className="vertical-label">من هنا تبدأ الحكاية</div><div className="intro-number">01</div><div className="line-accent" /></div><div className="intro-content"><SectionHeading kicker="عن المعهد" title="مساحة تتعلم فيها المهارة، وتكبر فيها الثقة" description="معهد التدريب المهني الطفيلة إناث هو مساحة تعليمية عملية تنتمي إلى مؤسسة التدريب المهني في الأردن، صُممت لتمنح الفتيات والسيدات مهارات قابلة للتطبيق وفرصاً أوسع للمستقبل." /><div className="intro-columns"><div><p>نؤمن أن كل مهارة مكتسبة هي بداية حقيقية للاستقلال. لذلك نقرّب التدريب من احتياجات سوق العمل، ونصنع بيئة آمنة تشجّع على التجربة، السؤال، والإنجاز.</p><a href="#البرامج" className="text-link">تعرّفي على برامجنا <ArrowLeft size={16} /></a></div><ul className="check-list"><li><Check size={17} /> مدربات متخصصات وبيئة داعمة</li><li><Check size={17} /> ورش عملية ومهارات مطلوبة</li><li><Check size={17} /> توجيه مهني نحو العمل الحر والتشغيل</li></ul></div></div></div>
        </section>

        <section className="why-section section-pad"><div className="container"><SectionHeading kicker="لماذا تختارين معهدنا؟" title="نُدرّبكِ على ما يصنع الفرق" description="من أول تجربة عملية حتى الخطوة التالية، نرافقكِ بعناية ووضوح." /><div className="why-grid"><div className="why-feature"><div className="why-feature-icon"><Crosshair /></div><h3>تدريب عملي متخصص</h3><p>تعلّم حقيقي داخل ورش مجهزة يقرّبكِ من متطلبات المهنة.</p><span>01</span></div><div className="why-feature"><div className="why-feature-icon"><ShieldCheck /></div><h3>بيئة آمنة وسليمة</h3><p>مساحة تحترم طموحكِ وتمنحكِ الثقة لتجربي وتتقدمي.</p><span>02</span></div><div className="why-feature"><div className="why-feature-icon"><BarChart3 /></div><h3>مهارات تواكب السوق</h3><p>برامج متنوعة تجمع بين الحرفة، التقنية، والمهارات الحياتية.</p><span>03</span></div><div className="why-feature"><div className="why-feature-icon"><HeartHandshake /></div><h3>توجيه نحو الفرص</h3><p>نساعدكِ على رؤية الخيارات وبناء الخطوة المهنية القادمة.</p><span>04</span></div></div></div></section>

        <section id="التخصصات" className="specialties-section section-pad"><div className="container"><div className="section-heading-row"><SectionHeading kicker="التخصصات المهنية" title="اختاري المسار الذي يشبهكِ" description="كل تخصص هنا هو بداية لقصة مهنية جديدة. تعرّفي على التفاصيل واختاري ما يناسب شغفكِ." /><a href="https://ereg.vtc.gov.jo/" target="_blank" rel="noreferrer" className="text-link desktop-link">بوابة التسجيل <ExternalLink size={16} /></a></div><div className="specialty-grid">{specialties.map((item, index) => { const Icon = item.icon; return <article key={item.title} className={`specialty-card ${index === 0 ? "specialty-card-featured" : ""}`}><div className="specialty-image"><img src={item.image} alt={item.title} loading="lazy" /><div className="specialty-icon"><Icon size={22} /></div><span className="specialty-number">0{index + 1}</span></div><div className="specialty-body"><span className="specialty-eyebrow">{item.eyebrow}</span><h3>{item.title}</h3><p>{item.description}</p><div className="specialty-meta"><span><Clock3 size={14} /> {item.duration}</span><span><BarChart3 size={14} /> {item.level}</span></div><button className="card-link" onClick={() => setSelected(item)}>التفاصيل <ChevronLeft size={17} /></button></div></article> })}</div></div></section>

        <section id="التسجيل" className="enroll-section"><div className="container enroll-inner"><div><span className="section-kicker light-kicker">خطوتكِ التالية</span><h2>ابدئي رحلتكِ المهنية الآن</h2><p>لا تنتظري الفرصة... اصنعيها بمهارة. اختاري تخصصكِ وابدئي طريقكِ نحو مستقبل مهني أفضل.</p></div><div className="enroll-action"><a href="https://ereg.vtc.gov.jo/" target="_blank" rel="noreferrer" className="button button-light">التسجيل الإلكتروني <ArrowLeft size={18} /></a><div className="support-row"><a href="https://wa.me/962798137070" target="_blank" rel="noreferrer"><MessageCircle size={16} /> واتساب 0798137070</a><a href="tel:066588481"><Phone size={15} /> 06-6588481</a></div></div></div></section>

        <section id="البرامج" className="programs-section section-pad"><div className="container"><SectionHeading kicker="برامج ومشاريع" title="أكثر من تدريب... منظومة تمكين" description="نوسّع أثر التدريب ببرامج تمنحكِ الأدوات لتبدئي، تتقدمي، وتتركي أثراً." /><div className="program-grid">{programs.map((program, index) => { const Icon = program.icon; return <div className="program-card" key={program.title}><div className="program-top"><span>0{index + 1}</span><Icon size={22} /></div><h3>{program.title}</h3><p>{program.description}</p><ArrowLeft className="program-arrow" size={19} /></div> })}</div></div></section>

        <section className="stats-section"><div className="container stats-grid">{stats.map(([number, label]) => <div className="stat-item" key={label}><strong>{number}</strong><span>{label}</span></div>)}</div></section>

        <section id="الأنشطة" className="news-section section-pad"><div className="container"><div className="section-heading-row"><SectionHeading kicker="الأنشطة والإنجازات" title="نبض المعهد لا يتوقف" description="من الورشة إلى الميدان، نحتفي بكل تجربة تعلّم وكل خطوة إنجاز." /><a href="#المعرض" className="text-link desktop-link">شاهدي اللحظات <ArrowLeft size={16} /></a></div><div className="news-grid">{news.map((item, index) => <article className={`news-card ${index === 0 ? "news-card-main" : ""}`} key={item.title}><div className="news-image"><img src={item.image} alt={item.title} loading="lazy" /><span>{item.type}</span></div><div className="news-body"><div className="news-date"><CalendarDays size={14} /> {item.date}</div><h3>{item.title}</h3><a href="#تواصل" className="card-link">اقرئي المزيد <ChevronLeft size={17} /></a></div></article>)}</div></div></section>

        <section id="المعرض" className="gallery-section section-pad"><div className="container"><SectionHeading kicker="معرض الصور" title="لحظات تُرى وتُحكى" description="لقطات من بيئة التدريب، العمل الجماعي، والمهارات التي تتحول إلى إنجاز." /><div className="gallery-grid">{gallery.map((item, index) => <button key={item.src} className={`gallery-tile gallery-${index + 1}`} onClick={() => setLightbox(item.src)} aria-label={`تكبير صورة: ${item.label}`}><img src={item.src} alt={item.label} loading="lazy" /><span><Search size={16} /> {item.label}</span></button>)}</div></div></section>

        <section className="story-section section-pad"><div className="container story-grid"><div className="story-visual"><img src={`${imageBase}sewing-detail_949d909c.jpeg`} alt="تدريب عملي داخل المشغل" /><div className="story-quote"><span>“</span><p>كل يد تتعلم مهارة، تبني مستقبلاً.</p></div></div><div className="story-copy"><SectionHeading kicker="قصتنا" title="نقيس نجاحنا بما تستطيع خريجاتنا أن يصنعنه" description="منذ انطلاقتنا، نعمل على جعل التدريب المهني أقرب، أوضح، وأكثر اتصالاً بحياة المتدربات وطموحاتهن." /><div className="timeline"><div className="timeline-item"><span>01</span><div><strong>بيئة تأسيس</strong><p>تعلّم آمن يبدأ من الاحتياج الحقيقي.</p></div></div><div className="timeline-item"><span>02</span><div><strong>مهارة قابلة للتطبيق</strong><p>من المعرفة إلى اليد، ومن الفكرة إلى المنتج.</p></div></div><div className="timeline-item"><span>03</span><div><strong>أثر يمتد</strong><p>فرص تشغيل، عمل حر، وثقة أكبر بالمستقبل.</p></div></div></div></div></div></section>

        <section className="testimonials-section section-pad"><div className="container testimonial-grid"><div className="testimonial-intro"><SectionHeading kicker="صوت المتدربات" title="تجاربهن بداية الإلهام" description="الكلمات الصادقة من داخل التجربة هي ما يدفعنا لنصنع تجربة أفضل كل يوم." /><div className="testimonial-score"><strong>4.9</strong><div><div className="stars">★★★★★</div><span>تجربة تدريبية موصى بها</span></div></div></div><div className="testimonial-card"><div className="quote-mark">“</div><p>في المعهد تعلّمت أن المهارة ليست مجرد مهنة، بل ثقة أقدر أن أحملها معي في كل مكان. اليوم لديّ خطة واضحة لمشروعي الصغير.</p><div className="testimonial-author"><div className="author-avatar">س</div><div><strong>سارة العوران</strong><span>خريجة تخصص خياط نساء</span></div><Star size={18} fill="currentColor" /></div></div></div></section>

        <section className="faq-section section-pad"><div className="container faq-grid"><div><SectionHeading kicker="الأسئلة الشائعة" title="كل ما تحتاجينه قبل البداية" description="إن لم تجدي إجابتك هنا، يسعدنا استقبال استفسارك عبر قنوات التواصل." /><a href="#تواصل" className="button button-outline">تواصلي معنا <MessageCircle size={17} /></a></div><div className="faq-list">{faqs.map(([question, answer], index) => <div className={`faq-item ${openFaq === index ? "active" : ""}`} key={question}><button onClick={() => setOpenFaq(openFaq === index ? null : index)} aria-expanded={openFaq === index}><span>{question}</span><ChevronDown size={18} /></button>{openFaq === index && <p>{answer}</p>}</div>)}</div></div></section>

        <section id="تواصل" className="contact-section section-pad"><div className="container contact-grid"><div className="contact-copy"><span className="section-kicker light-kicker">تواصلي معنا</span><h2>نحن هنا لنسمع<br /><em>خطوتكِ القادمة.</em></h2><p>معهد التدريب المهني الطفيلة إناث<br />مؤسسة التدريب المهني · الأردن</p><div className="contact-links"><a href="tel:066588481"><span><Phone size={18} /></span><div><small>هاتف المعهد</small><strong>06-6588481</strong></div></a><a href="https://wa.me/962798137070" target="_blank" rel="noreferrer"><span><MessageCircle size={18} /></span><div><small>الدعم الفني عبر واتساب</small><strong>0798137070</strong></div></a><div><span><Clock3 size={18} /></span><div><small>ساعات الدوام</small><strong>الأحد – الخميس · 8:00 – 15:00</strong></div></div></div></div><div className="map-card"><div className="map-surface"><div className="map-grid-lines" /><div className="map-pin"><span><Crosshair size={22} /></span><small>معهد التدريب المهني<br />الطفيلة إناث</small></div><div className="map-road road-one" /><div className="map-road road-two" /><div className="map-road road-three" /><div className="map-label label-one">الطفيلة</div><div className="map-label label-two">الأردن</div></div><a href="https://www.google.com/maps/search/?api=1&query=معهد+التدريب+المهني+الطفيلة+إناث" target="_blank" rel="noreferrer" className="map-link">افتحي الموقع على خرائط Google <ExternalLink size={16} /></a></div></div></section>
      </main>

      <footer className="site-footer"><div className="container footer-inner"><LogoMark compact /><p>مهارة اليوم، فرصة الغد.</p><div className="footer-social"><span aria-label="Facebook"><Facebook size={17} /></span><span aria-label="Instagram"><Instagram size={17} /></span><span aria-label="LinkedIn"><Laptop size={17} /></span></div><small>© 2026 معهد التدريب المهني الطفيلة إناث. جميع الحقوق محفوظة.</small></div></footer>

      {showTop && <button className="to-top" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="العودة للأعلى"><ChevronDown size={18} /></button>}

      {selected && <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label={`تفاصيل تخصص ${selected.title}`} onClick={() => setSelected(null)}><div className="specialty-modal" onClick={(event) => event.stopPropagation()}><button className="modal-close" onClick={() => setSelected(null)} aria-label="إغلاق"><X size={19} /></button><div className="modal-image"><img src={selected.image} alt={selected.title} /></div><div className="modal-content"><span className="specialty-eyebrow">{selected.eyebrow}</span><h2>{selected.title}</h2><p>{selected.description}</p><div className="modal-meta"><span><Clock3 size={15} /> {selected.duration}</span><span><BarChart3 size={15} /> {selected.level}</span></div><div className="modal-columns"><div><h4>المهارات المكتسبة</h4><ul>{selected.skills.map((skill) => <li key={skill}><Check size={15} /> {skill}</li>)}</ul></div><div><h4>فرص العمل</h4><ul>{selected.opportunities.map((opportunity) => <li key={opportunity}><Check size={15} /> {opportunity}</li>)}</ul></div></div><a href="https://ereg.vtc.gov.jo/" target="_blank" rel="noreferrer" className="button button-primary modal-cta">سجّلي في هذا التخصص <ArrowLeft size={17} /></a></div></div></div>}
      {lightbox && <div className="lightbox" role="dialog" aria-modal="true" onClick={() => setLightbox(null)}><button onClick={() => setLightbox(null)} aria-label="إغلاق"><X /></button><img src={lightbox} alt="صورة مكبرة من معرض المعهد" onClick={(event) => event.stopPropagation()} /></div>}
    </div>
  );
}

export { specialties };
